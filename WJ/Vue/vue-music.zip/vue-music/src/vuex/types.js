export const COM_SHOW_SIDE_BAR = 'COM_SHOW_SIDE_BAR' //边侧栏
export const SET_FULL_SCREEN = 'SET_FULL_SCREEN' // 设置播放器是否全屏幕展示
export const COM_SAVE_SEARCH_HISTORY = 'COM_SAVE_SEARCH_HISTORY' // 保存搜索历史

export const SET_PLAYLIST = 'SET_PLAYLIST' // 播放列表
export const SET_CURRENT_INDEX = 'SET_CURRENT_INDEX' //设置播放音乐的索引
export const SET_PLAYING = 'SET_PLAYING' 
export const SAVE_PLAY_HISTORY = 'SAVE_PLAY_HISTORY'
export const SAVE_FAVORITE_LIST = 'SAVE_FAVORITE_LIST'