
## css
- transition (过渡) 

animation:forwards


## js
setInerval (clearInterval)
setTimeout